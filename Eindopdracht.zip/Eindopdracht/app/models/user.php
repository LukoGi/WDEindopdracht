<?php

class User {
    public int $id;
    public string $username;
    public string $password;
}