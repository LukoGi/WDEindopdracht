<?php

class Product {
    public int $id;
    public string $title;
    public float $price;
    public string $description;
    public string $category;
    public string $image;
}