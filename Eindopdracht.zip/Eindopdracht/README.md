# Web Development 1 Eindopdracht
Inloggegevens administrator :
    Username : admin
    Password : admin
